# Attendance Tracking System
Simple Flask-based attendance app.