from flask import Flask, render_template, request, redirect

app = Flask(__name__)

students = []
attendance = {}

@app.route('/')
def index():
    return render_template('index.html', students=students)

@app.route('/add', methods=['POST'])
def add_student():
    name = request.form.get('name')
    if name:
        students.append(name)
    return redirect('/')

@app.route('/mark/<name>')
def mark_attendance(name):
    attendance[name] = "Present"
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
